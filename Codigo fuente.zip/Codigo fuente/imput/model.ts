
//function eventoEscucha(botones:string) {
//botones.document.getelementbyid()
//}