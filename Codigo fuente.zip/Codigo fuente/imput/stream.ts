export class Stream {
	categoria: string[];
	streamer: string[];

	constructor(){
        this.categoria = [];
		this.streamer = [];
    }
}