"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Stream = void 0;
class Stream {
    constructor() {
        this.categoria = [];
        this.streamer = [];
    }
}
exports.Stream = Stream;
