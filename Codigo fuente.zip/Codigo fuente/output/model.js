"use strict";
//function eventoEscucha(botones:string) {
//botones.document.getelementbyid()
//}
